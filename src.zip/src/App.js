// src/App.js


import AboutUs from "./components/AboutUs";
import Home from "./components/Homepage/Home";
import MenuBar from "./components/MenuBar/NavBar";
import Posts from "./components/Posts";
import ContactUs from "./components/Contactpage/ContactUs";
import Nottinghamshire from './components/Nottingham/Nottinghamshire'
import Leicestershire from "./components/Leicester/Leicestershire"
import Lincolnshire from "./components/Lincolnshire/Lincolnshire"
import SendEmail from "./email/sendemail"
import {Route,Routes} from "react-router-dom"

function App() {
  return (
 <>
  <MenuBar />
  
 <Routes>
  <Route path="/" element ={<Home />} />
  <Route path="/Home" element ={<Home />} />
  <Route path="/AboutUs" element ={<AboutUs />} />
  <Route path="/Posts" element ={<Posts />} />
  <Route path="/ContactUs" element ={<ContactUs />} />
  <Route path="/Nottinghamshire" element ={<Nottinghamshire />} />
  <Route path="/Leicestershire" element ={<Leicestershire />} />
  <Route path="/Lincolnshire" element ={<Lincolnshire />} />
  <Route path="/SendEmail" element={<SendEmail/>} />
 </Routes>
  
   
  </>
 
  );
}

export default App;