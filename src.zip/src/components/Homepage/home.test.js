// src/App.test.js

import { render, screen } from "@testing-library/react";
import Home from "./Home"

test("renders app title element", () => {
  render(<Home />);
  const titleElement = screen.getByText(/React Posts Sharer/i);
  expect(titleElement).toBeInTheDocument();
});