import './home.css'
import React from "react";
import  Card  from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import YoutubeEmbed from '../YoutubeEmbed';
export default function Home()
{
   
return (<>

<div className="home-page">

      <Row >
        <Col>
        <div class="header-text">
          <h2>Gilgal Pentecostal Assembly</h2>
        </div>
        </Col>
        <Col>
            <div class="header-text">
            <h1>English & Malayalam  Worship</h1>
             </div>
        </Col>
           
      </Row>
      <Row className="mb-6">
        <Col>
        <div class="header-text">
                <h6>Bible says to “love the Lord, our God with all your heart and with all your soul and with all your strength and with all your mind” <b>Luke 10:27</b>.</h6>
        </div>
       
            </Col>
           
      </Row>
      <Row className="mb-6">
        <Col>
        <div class="header-text">
          <h6>Welcome to <b>Gilgal Pentecostal Assembly</b>, your online destination for inspiration, worship, and the transformative power of the Gospel. We are delighted to have you join us in this virtual sanctuary where the timeless truths of God's Word come alive.</h6>
               
                <h6>At <b>GPA</b>, we are committed to spreading the message of hope, love, and redemption found in the Gospel of Jesus Christ. Whether you're seeking spiritual nourishment, exploring the Christian faith, or deepening your existing relationship with God, our platform is designed to be a source of encouragement and enlightenment for individuals from all walks of life.</h6>
                <h6>Explore a wealth of resources, including thought-provoking articles, uplifting devotionals, soul-stirring music, and insightful sermons. Our mission is to create a space where the Gospel is not only proclaimed but experienced—where hearts are touched, lives are transformed, and a community of believers can come together in the spirit of unity and love.</h6>
                <h6>Feel free to browse through our diverse content, engage in meaningful discussions, and discover the profound impact of the Gospel in your daily life. Whether you're a newcomer to faith or a seasoned believer, GPA is here to accompany you on your spiritual journey.</h6>
                <h6>Join us as we embark on a shared exploration of God's grace, mercy, and the boundless love that transcends all. May this digital sanctuary be a source of inspiration, encouragement, and connection as we celebrate the Good News together.</h6>
                <h6>Thank you for being a part of the GPA community. We invite you to dive into the rich tapestry of the Gospel and discover the transformative power that awaits.</h6>
                <h6>A church plays a key role in the life of a Christian. <b>GPA</b> aims to provide support, advice, love and kindness to the ones who need it. We thrive to be an example of Christ which enables us to open-heartedly welcome people from any backgrounds with love and respect. </h6>
                <br />
                <hstyle>We hope to see you there!</hstyle> 
        </div>
       
            </Col>
           
      </Row>
      <Row className="mb-3">

        <Col>
        <Card>
        <Card.Header> <YoutubeEmbed embedId="8_h-kO4SHuY" /></Card.Header>
         
        </Card>
           
         </Col>
         <Col>
         <Card>
        <Card.Header> 
        <b>Sunday Service</b> 
        </Card.Header>
                         <p>
                            Nottinhhamshire @ 9 am to 1 pm. 
                          </p>
                            <p>
                            Leicestershire  @ 9 am to 1 pm. 
                            </p>
                            <p>
                            Lincolnshire  @ 4 pm to 6:30 pm. 
                            </p>
            </Card>
         </Col>

      </Row>
      <Row>
        <Col>
        </Col>
      </Row>
      </div>

  </>
  
  )
}