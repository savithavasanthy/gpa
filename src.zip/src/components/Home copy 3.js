import '../Style/home.css'
import React from "react";
import  Card  from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import YoutubeEmbed from './YoutubeEmbed';
export default function Home()
{
   
return (<>

<div className='App'>
  
<Container>
      <Row>
        <Col>
        <div class="header-text">
          <h2>Gilgal Pentecostal Assembly</h2>
        </div>
        </Col>
        <Col>
            <div class="header-text">
            <h1>NOTTINGHAM , LEICESTER & LINCOLN</h1>
             </div>
        </Col>
           
      </Row>
      <Row className="mb-6">
        <Col>
        <div class="header-text">
                <h6>Bible says to “love the Lord, our God with all your heart and with all your soul and with all your strength and with all your mind” <b>Luke 10:27</b>. That is our ultimate vision.</h6>
        </div>
       
            </Col>
           
      </Row>
      <Row className="mb-6">
        <Col>
        <div class="header-text">
          <h6><b>G</b>reetings in the name of the <b>Lord Jesus Christ</b>. </h6>
                <h6> <b>GPA</b> is a multicultural family that are enthusiastic about the teaching of Christ and following in his footsteps.</h6>
                <h6>Our vision is to guide people and help them walk according to God’s will. The bible says to “love the Lord, our God with all your heart and with all your soul and with all your strength and with all your mind” <b>Luke 10:27</b>. That is our ultimate vision.</h6>
                <h6>A church plays a key role in the life of a Christian. <b>GPA</b> aims to provide support, advice, love and kindness to the ones who need it. We thrive to be an example of Christ which enables us to open-heartedly welcome people from any backgrounds with love and respect. </h6>
                <br />
                <hstyle>We hope to see you there!</hstyle> 
        </div>
       
            </Col>
           
      </Row>
      <Row className="mb-3">

        <Col>
        <Card>
        <Card.Header> <YoutubeEmbed embedId="8_h-kO4SHuY" /></Card.Header>
         
            </Card>
           
         </Col>
         <Col>
         <Card>
        <Card.Header> 
        <b>Sunday Service</b> 
        </Card.Header>
                         <p>
                            Nottinhhamshire @ 9 am to 1 pm. 
                          </p>
                            <p>
                            Leicestershire  @ 9 am to 1 pm. 
                            </p>
                            <p>
                            Lincolnshire  @ 4 pm to 6:30 pm. 
                            </p>
            </Card>
         </Col>

      </Row>
      <Row>
        <Col>
        </Col>
      </Row>
    </Container>
          
         
          </div>

  </>
  
  )
}