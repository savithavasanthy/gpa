import '../Style/home.css'
import React from "react";
import  Card  from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import YoutubeEmbed from './YoutubeEmbed';
import Form from 'react-bootstrap/Form';



export default function Home()
{
   
return (<>

<div className='App'>
  
<Container>
      <Row className="mb-3">
        <Col>
        <div class="header-text">
        <h2>Gilgal Pentecostal Assembly</h2>
            <h1>NOTTINGHAM , LEICESTER & LINCOLN</h1>
            <h6><b>G</b>reetings in the name of the <b>Lord Jesus Christ</b>. </h6>
                <h6> <b>GPA</b> is a multicultural family that are enthusiastic about the teaching of Christ and following in his footsteps.</h6>
                <h6>Our vision is to guide people and help them walk according to God’s will. The bible says to “love the Lord, our God with all your heart and with all your soul and with all your strength and with all your mind” <b>Luke 10:27</b>. That is our ultimate vision.</h6>
                <br/>
        </div>
        <Card>
          <Card.Body>
                <Card.Text>
                <h6>A church plays a key role in the life of a Christian. <b>GPA</b> aims to provide support, advice, love and kindness to the ones who need it. We thrive to be an example of Christ which enables us to open-heartedly welcome people from any backgrounds with love and respect. </h6>
                <br />
                <hstyle>We hope to see you there!</hstyle> 
                </Card.Text>
              </Card.Body>
            </Card>
            </Col>
           
      </Row>
      <Row className="mb-3">
        <Col>
        <h1><span class="label label-default"> Gilgal Pentecostal Assembly</span></h1>
        <Card>
          <Card.Body>
                <Card.Text>
                       <p>
                            GPA charity is a Christian teaching and worship ministry. We offer itinerant and online Hebraic and Messianic study, discipling Christians about their biblical foundation and rich spiritual heritage.
                            </p>
                            <p>
                            We embrace God's Kingdom and covenant promises for the church, Israel, and the nations, and the church's calling to build the Kingdom of God by sharing the Gospel and uniting Jew and Gentile Christians as one new man in Christ (Ephesians 2:14-16).
                            </p>
                            <p>
                            We know you will thoroughly enjoy our content-rich teachings, videos, and podcasts that will satisfy the most ardent scholars and students of the Bible.
                            </p>
                </Card.Text>
              </Card.Body>
            </Card>
            </Col>
            <Col className="md-6">
            <Form>
                <Form.Group className="mb-3" controlId="formGroupEmail">
                  <Form.Label>Email address</Form.Label>
                  <Form.Control type="email" placeholder="Enter email" />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formGroupPassword">
                  <Form.Label>Password</Form.Label>
                  <Form.Control type="password" placeholder="Password" />
                </Form.Group>
            </Form>
            </Col>
      </Row>
      <Row className="mb-3">

        <Col>
        <Card>
        <Card.Header> <YoutubeEmbed embedId="8_h-kO4SHuY" /></Card.Header>
         
            </Card>
           
         </Col>
         <Col>
           
         </Col>

      </Row>
      <Row>
        <Col>
        </Col>
      </Row>
    </Container>
          
         
          </div>

  </>
  
  )
}