import '../Style/aboutus.css'
import React from 'react';

import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

export default function AboutUs()
{
       
        return (
          <>
          <div  className="aboutus-page">
         
          <Row >
        <Col>
        <div class="header-text">
          <h2>AboutUs</h2>
        </div>
        </Col>
        <Col>
        <div class="header-text">
          <h2>Our Mission</h2>
        </div>
        </Col>
           
      </Row>
      <Row >
        <Col>
        <div >
          <h6>Welcome to <b>Gilgal Pentecostal Assembly</b>, a digital sanctuary where the light of the Gospel shines brightly. Our journey began with a vision to create an online space that goes beyond the ordinary—a place where the transformative power of God's Word is made accessible to all.</h6>
          <h6>If you are longing to know more about Christ personally and to be part of the AIC family, we invite you to come and be blessed in our Sunday Worship services in <b>GPA</b></h6>
        </div>
        </Col>
        <Col>
        <h6>At <b>Gilgal Pentecostal Assembly</b>, our mission is simple yet profound: to spread the message of God's love, grace, and redemption through the teachings of Jesus Christ. We strive to create an environment where individuals can encounter the life-changing truths found in the Gospel, fostering spiritual growth, and deepening their relationship with God.</h6>
        </Col>
           
      </Row>
          

      <Row >
        <Col>
        <div class="header-text">
          <h2>What We Believe</h2>
        </div>
        </Col>
        <Col>
        <div class="header-text">
          <h2>Our Vision</h2>
        </div>
        </Col>
        </Row>
        <Row >
        <Col>
        <div >
          <h6>Rooted in the Christian faith, we stand on the foundational beliefs of the Gospel:</h6>
          <h6><b>The Authority of Scripture:</b> We believe in the divine inspiration and authority of the Bible as the infallible Word of God.</h6>
          <h6><b>Salvation through Christ:</b> We affirm Jesus Christ as the Son of God, the Savior of humanity, and the way to eternal life.</h6>
          <h6><b>Love and Compassion:</b> We strive to embody the love and compassion demonstrated by Jesus, embracing all people with open hearts.</h6>
        </div>
        </Col>
        <Col>
        <div >
          <h6>We envision <b>Gilgal Pentecostal Assembly</b> as a global community of believers, seekers, and explorers on a shared journey of faith. Through a variety of multimedia resources, inspirational content, and a welcoming online space, we aim to:</h6>
          <h6><b>Inspire and Encourage:</b> Encourage believers in their spiritual walk and inspire seekers to explore the Christian faith. </h6>
          <h6><b>Celebrate Diversity:</b> Embrace the diversity of God's creation, fostering unity among believers from various backgrounds.</h6>
          <h6><b>Impact Lives:</b> Impact lives through the transformative power of the Gospel, bringing hope, healing, and restoration.</h6>
        </div>
        </Col>       
      </Row>
      <Row >
        <Col>
        <div class="header-text">
          <h2>Join Us on the Journey</h2>
        </div>
        <div>
        <h6>We invite you to be a part of our growing community at <b>Gilgal Pentecostal Assembly</b>. Whether you are taking your first steps in faith, seeking answers to life's questions, or desiring to deepen your spiritual understanding, know that you are welcome here.</h6>

        <h6>Thank you for being a part of our story. Together, let's explore the boundless grace and love found in the Gospel of Jesus Christ.</h6>
        </div>
        </Col>
       
        </Row>
         
          </div>
          </>
        );

}