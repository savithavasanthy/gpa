// src/components/Posts.js
import './Lincolnshire.css'
import React from "react";
import  Card  from 'react-bootstrap/Card';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row'
import Carousel from 'react-bootstrap/Carousel';
import Placeholder from 'react-bootstrap/Placeholder';
import myPicture1 from '../../images/1.jpg'
import myPicture2 from '../../images/2.jpg'
import myPicture3 from '../../images/3.png'
import Container from 'react-bootstrap/Container';

function Lincolnshire() {
  return (
   
<div className='Lincoln-page'>
<Container>
<Row >
  <Col>
  <Card>
            <Card.Header  bg="secondary">Gilgal Pentecostal Assembly Nottinhhamshire in England</Card.Header>
              <Card.Body>
                <Card.Title>
                Gilgal Pentecostal Assembly is registred charity operates Throughout England 
                </Card.Title>
                <Card.Text>
                <Placeholder as="p" animation="glow">
                 <Placeholder xs={12}>
                  
                 </Placeholder>
      </Placeholder>
                <p>
                            GPA charity is a Christian teaching and worship ministry. We offer itinerant and online Hebraic and Messianic study, discipling Christians about their biblical foundation and rich spiritual heritage.
                            </p>
                            <p>
                            We embrace God's Kingdom and covenant promises for the church, Israel, and the nations, and the church's calling to build the Kingdom of God by sharing the Gospel and uniting Jew and Gentile Christians as one new man in Christ (Ephesians 2:14-16).
                            </p>
                            <p>
                            We know you will thoroughly enjoy our content-rich teachings, videos, and podcasts that will satisfy the most ardent scholars and students of the Bible.
                            </p>
                           
                            We know you will thoroughly enjoy our content-rich teachings of the Bible.
                           
                </Card.Text>
              </Card.Body>
            </Card>

</Col>
<Col>
  <Card>
            <Card.Header>Gilgal Pentecostal Assembly Nottinhhamshire in England</Card.Header>
              <Card.Body>
              <Carousel data-bs-theme="dark">
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={myPicture1}
          alt="First slide" 
        />

      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={myPicture2}
          alt="Second slide"   
        />
        <Carousel.Caption>
          <h5>Second slide label</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={myPicture3}
          alt="Third slide"  
        />
        <Carousel.Caption>
          <h5>Third slide label</h5>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
              </Card.Body>
            </Card>

</Col>
  </Row>
</Container>

          
          </div>
  );
}

export default Lincolnshire;