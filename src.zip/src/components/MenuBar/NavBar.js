import React from 'react';
import { Navbar, Nav,NavDropdown, Container } from 'react-bootstrap';
import { Link,useMatch,useResolvedPath} from 'react-router-dom';
import styles  from  './NavBar.module.css'

export default function NavBar()
{
   
return (
<Navbar style={{ backgroundColor: '#FFFFFF' }} expand="lg" className="customnavbar fixed-top">
      <Container  className={styles.navbarContainer}>
        <Navbar.Brand>
           <img src={require('../../assets/logo.png')} height="100px" width="100px" alt="logo"/>
         
        </Navbar.Brand> 
        <Navbar.Toggle aria-controls="basic-navbar-nav"/>
        <Navbar.Collapse id="basic-navbar-nav" className='justify-content-end'  >
          <Nav className="mr-auto">
          <Nav.Link>
            <CustomLink to="/Home" className={styles.navLink} >Home</CustomLink>
           
        </Nav.Link>
        <Nav.Link>
            <CustomLink to="/AboutUs" className={styles.navLink}>AboutUs</CustomLink>
        </Nav.Link>
            <Nav.Link><CustomLink to="/Posts" className={styles.navLink}>Posts</CustomLink> </Nav.Link>
                <NavDropdown title="Churchs" className={styles.navDropdownlink}>
                    <NavDropdown.Item><CustomLink to="/Nottinhhamshire" className={styles.navLink}>Nottinghamshire</CustomLink></NavDropdown.Item>
                    <NavDropdown.Item><CustomLink to="/Leicestershire" className={styles.navLink}>Leicestershire </CustomLink></NavDropdown.Item>
                    <NavDropdown.Item><CustomLink to="/Lincolnshire" className={styles.navLink}>Lincolnshire</CustomLink></NavDropdown.Item>
                </NavDropdown>
        <Nav.Link><CustomLink to="/ContactUs" className={styles.navLink} >ContactUs</CustomLink></Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>

)

}

function CustomLink({to,children,  ...props}) {
  const resPath = useResolvedPath(to)
  const isActive = useMatch({ path : resPath.pathname, end : true})
  return(
      <li className={isActive ? "active":""}>
      <Link to={to} {...props}>{children}</Link>  
      </li>
  )
}



