import { Link,useMatch,useResolvedPath } from "react-router-dom"
import './MenuBar.css';
import 'bootstrap/dist/css/bootstrap.css'
import {Nav,Navbar,NavDropdown} from 'react-bootstrap'
import Container from 'react-bootstrap/Container';
export default function MenuBar()
{
   
return (
   
<div className="topnav-left"> 

<Navbar>
<Container>
   <Navbar.Brand>
    <img src={require('../../assets/logo.png')} height="100px" width="100px" alt="logo"/>
    </Navbar.Brand> 
    <Navbar.Toggle />
    <Navbar.Collapse>
    </Navbar.Collapse>
    <Nav>
        <Nav.Link>
            <CustomLink to="/Home"  >Home</CustomLink>
        </Nav.Link>
        <Nav.Link>
            <CustomLink to="/AboutUs">AboutUs</CustomLink>
        </Nav.Link>
            <Nav.Link><CustomLink to="/Posts">Posts</CustomLink> </Nav.Link>
                <NavDropdown title="Churchs">
                    <NavDropdown.Item><CustomLink to="/Nottinhhamshire" style={{ color:"black"}}>Nottinghamshire</CustomLink></NavDropdown.Item>
                    <NavDropdown.Item><CustomLink to="/Leicestershire" style={{color: "black"}}>Leicestershire </CustomLink></NavDropdown.Item>
                    <NavDropdown.Item><CustomLink to="/Lincolnshire" style={{color: "black"}}>Lincolnshire</CustomLink></NavDropdown.Item>
                </NavDropdown>
        <Nav.Link><CustomLink to="/ContactUs">ContactUs</CustomLink></Nav.Link>
    </Nav>
    </Container>
</Navbar>
        

</div>

)

}


function CustomLink({to,children,  ...props}) {
    const resPath = useResolvedPath(to)
    const isActive = useMatch({ path : resPath.pathname, end : true})
    return(
        <li className={isActive ? "active":""}>
        <Link to={to} {...props}>{children}</Link>  
        </li>
    )
}

