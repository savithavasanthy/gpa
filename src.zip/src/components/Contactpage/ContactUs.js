import './Contactus.css'
import React from 'react';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';


export default function ContactUs()
{
  return (
    <>
      <div className="contact-page">
  
     
 
        <Row className="mb-3">
          <Col>
          <div class="header-text">
          <h2>Sunday Service @ NG9 3HD</h2>
            
          </div>
         
              </Col>
              <Col>
            
              <div>
              <iframe title='gpaMap'
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2093.4157879426843!2d-1.2467520102612275!3d52.93577336860392!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4879e9b373204d27%3A0xf4401e49f66f66f4!2sMalayalam%20Pentecostal%20Church%20(Gilgal%20Pentecostal%20Assembly)%20Nottingham!5e0!3m2!1sen!2suk!4v1708704352146!5m2!1sen!2suk"
                width="600"
                height="450"
                frameborder="0"
                style={{ border: 0 }}
                allowfullscreen=""
                aria-hidden="false"
                tabindex="0"
              />
        </div>
       
       
              </Col>
             
        </Row>
        
        <Row className="mb-3">
  
          <Col>
         
           </Col>
           <Col>
           
           </Col>
  
        </Row>
        <Row>
          <Col>
          </Col>
        </Row>
      
            
           
            </div>
    </>
  );

}